package com.aixcc.mock_java;

import java.util.Arrays;
import java.util.List;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void executeCommand(String data) {
        //Only "ls", "pwd", and "echo" commands are allowed.
        try{
            ProcessBuilder processBuilder = new ProcessBuilder();
            processBuilder.command(data);
            Process process = processBuilder.start();
            process.waitFor();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
